﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIS.RDP.BPPS.SFTPScriptsGenerator
{
    public class PayeeFileInfo
    {
        public string cszThirdPtyDisbType { get; set; }
        public string cszReleaseTime { get; set; }
        public string cszPushInd { get; set; }
        public string cszSourcePath { get; set; }
        public string cszSourceFileName { get; set; }
        public string cszDestPath { get; set; }
        public string cszDestFileName { get; set; }

    }
}
